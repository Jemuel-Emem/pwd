<x-user-layout>
    <div>

        <div class="  flex justify-center w-screen">
            <livewire:user.requirements />
        </div>

    </div>
</x-user-layout>
