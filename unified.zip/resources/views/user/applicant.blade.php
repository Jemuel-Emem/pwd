<x-user-layout>
    <div>

        <div class=" h-screen flex justify-center w-screen">
            <livewire:user.applicant />
        </div>

    </div>
</x-user-layout>
