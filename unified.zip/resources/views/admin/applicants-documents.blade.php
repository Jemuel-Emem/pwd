<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.applicants-documents/>
        </div>

    </div>
</x-admin-layout>
