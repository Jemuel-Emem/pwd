<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.adddocu/>
        </div>

    </div>
</x-admin-layout>
