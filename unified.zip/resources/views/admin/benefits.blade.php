<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.benefits />
        </div>

    </div>
</x-admin-layout>
