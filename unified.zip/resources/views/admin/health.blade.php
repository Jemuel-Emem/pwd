<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.health/>
        </div>

    </div>
</x-admin-layout>
