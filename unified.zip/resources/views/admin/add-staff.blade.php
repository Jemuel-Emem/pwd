<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.add-staff/>
        </div>

    </div>
</x-admin-layout>
