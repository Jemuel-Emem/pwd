<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.beneficiaries/>
        </div>

    </div>
</x-admin-layout>
