<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.applicant />
        </div>

    </div>
</x-admin-layout>
