<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.add-applicant/>
        </div>

    </div>
</x-admin-layout>
