<x-admin-layout>
    <div>

        <div class="">
            <livewire:admin.report/>
        </div>

    </div>
</x-admin-layout>
