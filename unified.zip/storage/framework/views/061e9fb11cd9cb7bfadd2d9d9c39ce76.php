<div>
    <!-- Simplicity is an acquired taste. - Katharine Gerould -->
</div>
<?php /**PATH D:\laravel\unified\resources\views\admin\view-benefits.blade.php ENDPATH**/ ?>